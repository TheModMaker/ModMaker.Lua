﻿using ModMaker.Lua.Parser;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Globalization;
using System.Collections.Generic;
using ModMaker.Lua.Parser.Items;

namespace TestProject
{
    /// <summary>
    /// This is a test class for PlainParserTest and is intended
    /// to contain all PlainParserTest Unit Tests
    ///</summary>
    [TestClass()]
    public class PlainParserTest
    {
        private TestContext testContextInstance;

        /// <summary>
        /// Gets or sets the test context which provides
        /// information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        void ValidateDebug(Token debug, string prefix, string value, long startLine, long startPos, long endLine, long endPos)
        {
            Assert.AreEqual(value, debug.Value, prefix + ".Debug.Value");
            Assert.AreEqual(startLine, debug.StartLine, prefix + ".Debug.StartLine");
            Assert.AreEqual(startPos, debug.StartPos, prefix + ".Debug.StartPos");
            Assert.AreEqual(endLine, debug.EndLine, prefix + ".Debug.StartLine");
            Assert.AreEqual(endPos, debug.EndPos, prefix + ".Debug.EndPos");
        }

        /// <summary>
        /// A test for PlainParser.Parse with valid input
        /// testing for valid DebugInfo also.
        ///</summary>
        [TestMethod()]
        public void GenralParse()
        {
            PlainParser target = new PlainParser();
            TextElementEnumerator input1 = StringInfo.GetTextElementEnumerator(
@"local a = 12 
t = { [34]= function() print(i) end } 
function Some(a, ...) 
    a, b, c = ... 
    for i= 12, 23 do 
        print(i) 
    end 
end"
                );
            IParseItem actual;
            actual = target.Parse(new Tokenizer(input1, null), null, null);

            // check the main block
            BlockItem block = actual as BlockItem;
            Assert.IsInstanceOfType(actual, typeof(BlockItem));
            Assert.IsNotNull(block.Children);
            Assert.AreEqual(3, block.Children.Count, "Block.Children.Count");
            ValidateDebug(block.Debug, "Block", "local a = 12 t = { [ 34 ] = function ( ) print ( i ) end } function Some ( a , ... ) a , b , c = ... for i = 12 , 23 do print ( i ) end end", 1, 1, 8, 4);

            // check the return statement of the main block
            {
                ReturnItem ret = block.Return;
                Assert.IsInstanceOfType(block.Return, typeof(ReturnItem));
                ValidateDebug(ret.Debug, "Block.Return", null, 0, 0, 0, 0);
                Assert.IsNotNull(ret.Expressions);
                Assert.AreEqual(0, ret.Expressions.Count);
            }

            // local a = 12
            {
                AssignmentItem init = block.Children[0] as AssignmentItem;
                Assert.IsNotNull(init, "Block.Children[0]");
                Assert.AreEqual(true, init.Local);
                ValidateDebug(init.Debug, "Block.Children[0]", "local a = 12", 1, 1, 1, 13);

                // check the names
                {
                    Assert.IsNotNull(init.Names, "Block.Children[0].Names");
                    Assert.AreEqual(1, init.Names.Count, "Block.Children[0].Names.Count");

                    NameItem name = init.Names[0] as NameItem;
                    Assert.IsNotNull(name, "Block.Children[0].Names[0]");
                    Assert.AreEqual("a", name.Name, "Block.Children[0].Names[0].Name");
                    ValidateDebug(name.Debug, "Block.Children[0].Names[0]", "a", 1, 7, 1, 8);
                }

                // check the expressions
                {
                    Assert.IsNotNull(init.Expressions, "Block.Children[0].Expressions");
                    Assert.AreEqual(1, init.Expressions.Count, "Block.Children[0].Expressions.Count");

                    LiteralItem literal = init.Expressions[0] as LiteralItem;
                    Assert.IsNotNull(literal, "Block.Children[0].Expressions[0]");
                    Assert.AreEqual(12.0, literal.Value, "Block.Children[0].Expressions[0].Value");
                    ValidateDebug(literal.Debug, "Block.Children[0].Expressions[0]", "12", 1, 11, 1, 13);
                }
            }

            // t = { [34]= function() print(i) end }
            {
                AssignmentItem init = block.Children[1] as AssignmentItem;
                Assert.IsNotNull(init, "Block.Children[1]");
                Assert.AreEqual(false, init.Local);
                ValidateDebug(init.Debug, "Block.Children[1]", "t = { [ 34 ] = function ( ) print ( i ) end }", 2, 1, 2, 38);

                // check the names
                {
                    Assert.IsNotNull(init.Names, "Block.Children[1].Names");
                    Assert.AreEqual(1, init.Names.Count, "Block.Children[1].Names.Count");

                    NameItem name = init.Names[0] as NameItem;
                    Assert.IsNotNull(name, "Block.Children[1].Names[0]");
                    Assert.AreEqual("t", name.Name, "Block.Children[1].Names[0].Name");
                    ValidateDebug(name.Debug, "Block.Children[1].Names[0]", "t", 2, 1, 2, 2);
                }

                // check the expressions
                {
                    Assert.IsNotNull(init.Expressions, "Block.Children[1].Expressions");
                    Assert.AreEqual(1, init.Expressions.Count, "Block.Children[1].Expressions.Count");

                    TableItem table = init.Expressions[0] as TableItem;
                    Assert.IsNotNull(table, "Block.Children[1].Expressions[0]");
                    ValidateDebug(table.Debug, "Block.Children[1].Expressions[0]", "{ [ 34 ] = function ( ) print ( i ) end }", 2, 5, 2, 38);

                    Assert.IsNotNull(table.Fields, "Block.Children[1].Expressions[0].Fields");
                    Assert.AreEqual(1, table.Fields.Count, "Block.Children[1].Expressions[0].Fields.Count");

                    var field = table.Fields[0];
                    {
                        LiteralItem literal = field.Item1 as LiteralItem;
                        Assert.IsNotNull(literal, "Block.Children[1].Expressions[0].Fields[0].Item1");
                        Assert.AreEqual(34.0, literal.Value, "Block.Children[1].Expressions[0].Fields[0].Item1.Value");
                        ValidateDebug(literal.Debug, "Block.Children[1].Expressions[0].Fields[0].Item1", "34", 2, 8, 2, 10);
                    }
                    {
                        FuncDefItem func = field.Item2 as FuncDefItem;
                        Assert.IsNotNull(func, "Block.Children[1].Expressions[0].Fields[0].Item2");
                        Assert.IsNull(func.InstanceName, "Block.Children[1].Expressions[0].Fields[0].Item2.InstanceName");
                        Assert.IsNull(func.Prefix, "Block.Children[1].Expressions[0].Fields[0].Item2.Prefix");
                        Assert.AreEqual(false, func.Local, "Block.Children[1].Expressions[0].Fields[0].Item2.Local");
                        Assert.IsNull(func.FunctionInformation, "Block.Children[1].Expressions[0].Fields[0].Item2.FunctionInformation");
                        ValidateDebug(func.Debug, "Block.Children[1].Expressions[0].Fields[0].Item2", "function ( ) print ( i ) end", 2, 13, 2, 36);

                        // validate the block
                        {
                            BlockItem funcBlock = func.Block;
                            Assert.IsNotNull(funcBlock, "Block.Children[1].Expressions[0].Fields[0].Item2.Block");
                            ValidateDebug(funcBlock.Debug, "Block.Children[1].Expressions[0].Fields[0].Item2.Block", "print ( i )", 2, 24, 2, 32);


                            // validate the return
                            {
                                ReturnItem ret = funcBlock.Return;
                                Assert.IsNotNull(ret, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Return");
                                ValidateDebug(ret.Debug, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Return", null, 0, 0, 0, 0);
                                Assert.IsNotNull(ret.Expressions, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Return.Expressions");
                                Assert.AreEqual(0, ret.Expressions.Count, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Return.Expressions.Count");
                            }

                            // validate the statement
                            {
                                Assert.IsNotNull(funcBlock.Children, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children");
                                Assert.AreEqual(1, funcBlock.Children.Count, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children.Count");

                                // print ( i )
                                {
                                    FuncCallItem call = funcBlock.Children[0] as FuncCallItem;
                                    Assert.IsNotNull(call, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0]");
                                    Assert.AreEqual(true, call.Statement, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0].Statement");
                                    Assert.IsNull(call.InstanceName, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0].InstanceName");
                                    ValidateDebug(call.Debug, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0]", "print ( i )", 2, 24, 2, 32);

                                    // validate the prefix
                                    {
                                        NameItem name = call.Prefix as NameItem;
                                        Assert.IsNotNull(call.Prefix, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0].Prefix");
                                        Assert.AreEqual("print", name.Name, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0].Prefix.Name");
                                        ValidateDebug(name.Debug, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0].Prefix.Name", "print", 2, 24, 2, 29);
                                    }

                                    // validate the arguments
                                    {
                                        Assert.IsNotNull(call.Arguments, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0].Arguments");
                                        Assert.AreEqual(1, call.Arguments.Count, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0].Arguments.Count");

                                        NameItem name = call.Arguments[0].Item1 as NameItem;
                                        Assert.IsNotNull(name, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0].Arguments[0]");
                                        Assert.AreEqual("i", name.Name, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0].Arguments[0].Name");
                                        ValidateDebug(name.Debug, "Block.Children[1].Expressions[0].Fields[0].Item2.Block.Children[0].Arguments[0]", "i", 2, 30, 2, 31);
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // function Some(a, ...) 
            {
                FuncDefItem func = block.Children[2] as FuncDefItem;
                Assert.IsNotNull(func, "Block.Children[2]");
                Assert.AreEqual(false, func.Local, "Block.Children[2].Local");
                Assert.IsNull(func.InstanceName, "Block.Children[2].InstanceName");
                ValidateDebug(func.Debug, "Block.Children[2]", "function Some ( a , ... ) a , b , c = ... for i = 12 , 23 do print ( i ) end end", 3, 1, 8, 4);

                // validate the block
                {
                    BlockItem someBlock = func.Block;
                    ValidateDebug(someBlock.Debug, "Block.Children[2].Block", "a , b , c = ... for i = 12 , 23 do print ( i ) end", 4, 5, 7, 8);

                    // validate the return
                    {
                        ReturnItem ret = someBlock.Return;
                        Assert.IsNotNull(ret, "Block.Children[2].Block.Return");
                        ValidateDebug(ret.Debug, "Block.Children[2].Block.Return", null, 0, 0, 0, 0);
                        Assert.IsNotNull(ret.Expressions, "Block.Children[2].Block.Return.Expressions");
                        Assert.AreEqual(0, ret.Expressions.Count, "Block.Children[2].Block.Return.Expressions.Count");
                    }

                    // check the children
                    {
                        Assert.IsNotNull(someBlock.Children, "Block.Children[2].Block.Children");
                        Assert.AreEqual(2, someBlock.Children.Count, "Block.Children[2].Block.Children.Count");

                        // a , b , c = ...
                        {
                            AssignmentItem varInit = someBlock.Children[0] as AssignmentItem;
                            Assert.IsNotNull(varInit, "Block.Children[2].Block.Children[0]");
                            Assert.AreEqual(false, varInit.Local, "Block.Children[2].Block.Children[0].Local");
                            ValidateDebug(varInit.Debug, "Block.Children[2].Block.Children[0]", "a , b , c = ...", 4, 5, 4, 18);

                            // validate the names
                            {
                                Assert.IsNotNull(varInit.Names, "Block.Children[2].Block.Children[0].Names");
                                Assert.AreEqual(3, varInit.Names.Count, "Block.Children[2].Block.Children[0].Names.Count");

                                NameItem name = varInit.Names[0] as NameItem;
                                Assert.IsNotNull(name, "Block.Children[2].Block.Children[0].Names[0]");
                                Assert.AreEqual(name.Name, "a", "Block.Children[2].Block.Children[0].Names[0].Name");
                                ValidateDebug(name.Debug, "Block.Children[2].Block.Children[0].Names[0]", "a", 4, 5, 4, 6);

                                name = varInit.Names[1] as NameItem;
                                Assert.IsNotNull(name, "Block.Children[2].Block.Children[0].Names[1]");
                                Assert.AreEqual(name.Name, "b", "Block.Children[2].Block.Children[0].Names[1].Name");
                                ValidateDebug(name.Debug, "Block.Children[2].Block.Children[0].Names[1]", "b", 4, 8, 4, 9);

                                name = varInit.Names[2] as NameItem;
                                Assert.IsNotNull(name, "Block.Children[2].Block.Children[0].Names[2]");
                                Assert.AreEqual(name.Name, "c", "Block.Children[2].Block.Children[0].Names[2].Name");
                                ValidateDebug(name.Debug, "Block.Children[2].Block.Children[0].Names[2]", "c", 4, 11, 4, 12);
                            }
                            // validate the expressions
                            {
                                Assert.IsNotNull(varInit.Expressions, "Block.Children[2].Block.Children[0].Expressions");
                                Assert.AreEqual(1, varInit.Expressions.Count, "Block.Children[2].Block.Children[0].Expressions.Count");

                                NameItem name = varInit.Expressions[0] as NameItem;
                                Assert.IsNotNull(name, "Block.Children[2].Block.Children[0].Expressions[0]");
                                Assert.AreEqual(name.Name, "...", "Block.Children[2].Block.Children[0].Expressions[0].Name");
                                ValidateDebug(name.Debug, "Block.Children[2].Block.Children[0].Expressions[0]", "...", 4, 15, 4, 18);
                            }
                        }
                        // for i= 12, 23 do print ( i ) end
                        {
                            ForNumItem forLoop = someBlock.Children[1] as ForNumItem;
                            Assert.IsNotNull(forLoop, "Block.Children[2].Block.Children[1]");
                            ValidateDebug(forLoop.Debug, "Block.Children[2].Block.Children[1]", "for i = 12 , 23 do print ( i ) end", 5, 5, 7, 8);

                            // validate the name
                            {
                                NameItem name = forLoop.Name;
                                Assert.IsNotNull(name, "Block.Children[2].Block.Children[1].Name");
                                ValidateDebug(name.Debug, "Block.Children[2].Block.Children[1].Name", "i", 5, 9, 5, 10);
                                Assert.AreEqual(name.Name, "i", "Block.Children[2].Block.Children[1].Name.Name");
                            }

                            // validate the start
                            {
                                LiteralItem lit = forLoop.Start as LiteralItem;
                                Assert.IsNotNull(lit, "Block.Children[2].Block.Children[1].Start");
                                Assert.AreEqual(12.0, lit.Value, "Block.Children[2].Block.Children[1].Start.Value");
                                ValidateDebug(lit.Debug, "Block.Children[2].Block.Children[1].Start", "12", 5, 12, 5, 14);
                            }

                            // validate the limit
                            {
                                LiteralItem lit = forLoop.Limit as LiteralItem;
                                Assert.IsNotNull(lit, "Block.Children[2].Block.Children[1].Limit");
                                Assert.AreEqual(23.0, lit.Value, "Block.Children[2].Block.Children[1].Limit.Value");
                                ValidateDebug(lit.Debug, "Block.Children[2].Block.Children[1].Limit", "23", 5, 16, 5, 18);
                            }

                            // validate the step
                            {
                                Assert.IsNull(forLoop.Step, "Block.Children[2].Block.Children[1].Step");
                            }

                            // validate the block
                            {
                                BlockItem forBlock = forLoop.Block;
                                ValidateDebug(forBlock.Debug, "Block.Children[2].Block.Children[1].Block", "print ( i )", 6, 9, 6, 17);
                                Assert.IsNull(forBlock.Return, "Block.Children[2].Block.Children[1].Block.Return");

                                // validate the statement
                                {
                                    Assert.IsNotNull(forBlock.Children, "Block.Children[2].Block.Children[1].Block.Children");
                                    Assert.AreEqual(1, forBlock.Children.Count, "Block.Children[2].Block.Children[1].Block.Children.Count");

                                    // print ( i )
                                    {
                                        FuncCallItem call = forBlock.Children[0] as FuncCallItem;
                                        Assert.IsNotNull(call, "Block.Children[2].Block.Children[1].Block.Children[0]");
                                        Assert.AreEqual(true, call.Statement, "Block.Children[2].Block.Children[1].Block.Children[0].Statement");
                                        Assert.IsNull(call.InstanceName, "Block.Children[2].Block.Children[1].Block.Children[0].InstanceName");
                                        ValidateDebug(call.Debug, "Block.Children[2].Block.Children[1].Block.Children[0]", "print ( i )", 6, 9, 6, 17);

                                        // validate the prefix
                                        {
                                            NameItem name = call.Prefix as NameItem;
                                            Assert.IsNotNull(call.Prefix, "Block.Children[2].Block.Children[1].Block.Children[0].Prefix");
                                            Assert.AreEqual("print", name.Name, "Block.Children[2].Block.Children[1].Block.Children[0].Prefix.Name");
                                            ValidateDebug(name.Debug, "Block.Children[2].Block.Children[1].Block.Children[0].Prefix.Name", "print", 6, 9, 6, 14);
                                        }

                                        // validate the arguments
                                        {
                                            Assert.IsNotNull(call.Arguments, "Block.Children[2].Block.Children[1].Block.Children[0].Arguments");
                                            Assert.AreEqual(1, call.Arguments.Count, "Block.Children[2].Block.Children[1].Block.Children[0].Arguments.Count");

                                            NameItem name = call.Arguments[0].Item1 as NameItem;
                                            Assert.IsNotNull(name, "Block.Children[2].Block.Children[1].Block.Children[0].Arguments[0]");
                                            Assert.AreEqual("i", name.Name, "Block.Children[2].Block.Children[1].Block.Children[0].Arguments[0].Name");
                                            ValidateDebug(name.Debug, "Block.Children[2].Block.Children[1].Block.Children[0].Arguments[0]", "i", 6, 15, 6, 16);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
